<?php
if (isset($_GET['a'])) {
    $link = base64_decode($_GET['a']);
}
?>
<!doctype html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>即将离开网站</title>
    <style>
        html {
            background: #f4f5f5;
        }

        #box {
            margin: auto;
            background: #fff;
            padding: 10px 30px;
            margin-top: 10%;
            max-width: 500px;
            box-sizing: border-box;
            border: 1px solid #e5e6eb;
            border-radius: 2px;
        }

        .note {
            font-size: 18px;
            line-height: 20px;
        }

        .link {
            padding: 16px 0 24px;
            border-bottom: 1px solid #e5e6eb;
            position: relative;
            color: gray;
            font-family: "PingFang SC";
            font-size: 14px;
            word-break: break-all;

        }
        .btn-plane {
           text-align: right;
        }
        button {
            margin-top: 20px;
            color: #fff;
            border-radius: 3px;
            border: none;
            background: #007fff;
            height: 32px;
            font-size: 14px;
            padding: 0 14px;
            cursor: pointer;
            outline: 0;
        }
        button a{
            color: #fff;
            text-decoration:none
        }
    </style>
</head>
<body>
<div id="box">
    <p class="note">即将离开本网站，请注意账号财产安全</p>
    <p class="link"><?php echo $link ?></p>
    <p class="btn-plane">
        <button><a href="<?php echo $link ?>" rel="nofollow">继续访问</a></button>
    </p>
</div>
</body>
</html>
